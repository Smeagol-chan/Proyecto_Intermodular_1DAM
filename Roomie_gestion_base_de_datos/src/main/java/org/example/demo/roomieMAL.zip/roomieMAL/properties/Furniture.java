package org.example.demo.roomieMAL.properties;

import java.util.Objects;

public class Furniture
{
    private int id;
    private String name;
    private String description;

    public Furniture(int id, String name, String description)
    {
        this.id = id;
        this.name = name;
        this.description = description;
    }

    public Furniture(int id, String name)
    {
        this(id, name, null);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Furniture furniture = (Furniture) o;
        return id == furniture.id;
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(id);
    }
}
