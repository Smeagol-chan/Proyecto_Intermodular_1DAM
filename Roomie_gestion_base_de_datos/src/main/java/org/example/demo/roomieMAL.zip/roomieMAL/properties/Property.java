package org.example.demo.roomieMAL.properties;

import org.example.demo.roomieMAL.shared_usage.expections.IllegalStatusException;
import org.example.demo.roomieMAL.shared_usage.expections.PorpertyNotConfirmedExpection;
import org.example.demo.roomieMAL.shared_usage.expections.UnableToAddException;
import org.example.demo.roomieMAL.shared_usage.expections.UnableToRemoveException;
import org.example.demo.roomieMAL.users.Owner;

import java.util.*;

public class Property
{
    private static final String DEFAULT_STATUS = "Pending";
    private static final String[] STATUS_PERMITTED = {"Pending", "Confirmed", "Denied"};

    private String address;
    private Owner owner;
    private String status;
    private double surface;
    private HashSet<Room> roomList;

    public Property(String address, Owner owner, String status, double surface)
    {
        this.address = address;
        this.owner = owner;
        setStatus(status);
        this.surface = surface;
        roomList = new HashSet<>();
    }

    public Property(String address, Owner owner, double surface)
    {
        this(address, owner, DEFAULT_STATUS, surface);
    }

    public String getAddress() {
        return address;
    }

    public Owner getOwner() {
        return owner;
    }

    public void setOwner(Owner owner) {
        this.owner = owner;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status)
    {
        if(Arrays.asList(STATUS_PERMITTED).contains(status)) this.status = status;
        else throw new IllegalStatusException();
    }

    public double getSurface() {
        return surface;
    }

    public void setSurface(double surface) {
        this.surface = surface;
    }

    public Set<Room> getRoomList()
    {
        return Collections.unmodifiableSet(roomList);
    }

    public void addRoom(Room room)
    {
        if(status.equals("Confirmed"))
        {
            if(roomList.contains(room)) throw new UnableToAddException();
            else roomList.add(room);
        }
        else throw new PorpertyNotConfirmedExpection(status);
    }

    public void removeRoom(Room room)
    {
        if(status.equals("Confirmed"))
        {
            if(roomList.contains(room)) roomList.remove(room);
            else throw new UnableToRemoveException();
        }
        else throw new PorpertyNotConfirmedExpection(status);
    }

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        Property property = (Property) o;
        return Objects.equals(address, property.address);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(address);
    }
}
