package org.example.demo.roomieMAL.shared_usage.expections;

public class IllegalStatusException extends RuntimeException {
    public IllegalStatusException() {
        super("Invalid status.");
    }
}
