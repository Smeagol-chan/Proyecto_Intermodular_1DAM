package org.example.demo.roomieMAL.shared_usage.expections;

public class PorpertyNotConfirmedExpection extends RuntimeException {
    public PorpertyNotConfirmedExpection(String status) {
        super("The property have to be confirmed by an administrator. Current status: "+ status);
    }
}
