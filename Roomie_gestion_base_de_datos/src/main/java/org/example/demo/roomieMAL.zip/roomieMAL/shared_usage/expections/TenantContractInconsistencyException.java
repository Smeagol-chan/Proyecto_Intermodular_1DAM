package org.example.demo.roomieMAL.shared_usage.expections;

public class TenantContractInconsistencyException extends RuntimeException {
    public TenantContractInconsistencyException(String message) {
        super(message);
    }
}
